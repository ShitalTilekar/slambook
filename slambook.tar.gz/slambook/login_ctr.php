

<?php
session_start();
$servername = "Localhost";
$username1 = "root";
$password1 = "qwerty";
$dbname = "slambook";

//require_once("SQLSettings.php");

$user = $_POST["username"];
$pass = $_POST["password"];
$conn = new mysqli($servername, $username1, $password1, $dbname);
//$cn1 = new connection;    
//$conn1 = $cn1->getConnection();
	
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}



//session_start();

	
	
	$sql = "INSERT INTO login (username, password) VALUES ( '$user', '$pass')";
	$conn->query($sql);
	
	
	if($_POST['username'] && $_POST['password'])
	{
		
		$query = "SELECT password FROM signin where username = '$user'";
			$result =mysqli_query($conn,$query);
			if (mysqli_num_rows($result) > 0) {
				$row = mysqli_fetch_assoc($result);
				if((strcmp($row["password"], $pass)) == 0) {
					
						header('Location: slambook.php'); 
					}
					else{
						$_SESSION["flag"] = 1;
						header('Location: login.php');
					}
				}
	}
	

////header("location: slambook.php");
?>
