<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>
slambook created by shital tilekar...
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->

</head>

<body>
<!-- PRELOADER STARTS HERE -->
  <div class="shym-preloader"></div>
  <!-- /PRELOADER ENDS HERE-->
  
  
  
<!-- HEADER STARTS HERE --> 
 <header class="navbar navbar-inverse navbar-fixed-top heading" role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle togglebutton" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>


</button>


 <h3>My Slambook...</h3></a>

</div>

 <div class="collapse navbar-collapse menubar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" ><i class="fa fa-fw fa-home"></i>Home</a>
					<ul class="dropdown-menu">
					
					</ul>
                    
                    
                 
                        
            </div>
			
</div>
</header><!---->

<!-- HEADER ENDS HERE -->

<!--GALLERY STARTS HERE -->

  <section class='gallery'>
 
<footer class="shym-contact">
      		 <!--======= GET IN TOUCH PART =========-->
		
            <div class="col-md-6 col-sm-6"> <i class="ion-flag"></i>
              <h4><center>LOG IN.....</h4></center>
              <div id="contact_form">
                <form id="form3" name="form3" class="contact-form " action="login_ctr.php" accept-charset="utf-8" method="post" >
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">

                        <label><span>Username</span>
			
                          <input name="username" type="text" placeholder="username"/>
                        </label>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>
                          <input name="password" type="password"  id="10" placeholder="password"/>
                        </label>
<input name="submit" type="submit" value="LOG IN" onClick="isValid();" />
                      </div>
                    </div>
                    

                    </div>
                </form>
		            <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
		</div>
      </div>
    </div>

    
  </footer>
   
  
</section>
  
 

	
  
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script> 
	<script src="js/scrollReveal.js"></script>
	<script src="js/function.js"></script>
	
	


   	





</body>
<script>
<!--
 function isValid()
 {
 
 // alert("hi");
	var user;
	user=document.form3.username.value;
	var pass1;
	pass1=document.form3.password.value;
	if(user=="" && pass1=="")
	{
		alert("Please enter username & Password");
		return false;
	}
	else if(user=="")
	{
		alert("please enter username");
		return false;
	}
	
	else if(pass1=="")
	{
		alert("please enter password");
		return false;
	}
	
	//check();
	return true;
}
  
 -->
</script> 
</html>

<?php 
	if(isset($_GET['user']))
	{//print_r("@@@@@@@@@@@");
		?>
        <script>
		
		document.getElementById('lblemail').style.display = "block";
		document.getElementById('lblemail').innerHTML ="You are not Register";
		//alert("QQQQQQQQQQQ");
		</script>
        <?php }?>

