<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>
slambook created by shital tilekar...
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->

</head>

<body>
<!-- PRELOADER STARTS HERE -->
  <div class="shym-preloader"></div>
  <!-- /PRELOADER ENDS HERE-->
  
  
  
<!-- HEADER STARTS HERE --> 
 <header class="navbar navbar-inverse navbar-fixed-top heading" role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle togglebutton" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>


</button>


 <h3>My Slambook...</h3></a>

</div>

 <div class="collapse navbar-collapse menubar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" ><i class="fa fa-fw fa-home"></i>Home</a>
					<ul class="dropdown-menu">
					
					</ul>
                   
                    <li><a href="login.php"></i>LOGIN...</a></li>
                 
                        
            </div>
			
</div>
</header><!---->

<!-- HEADER ENDS HERE -->

<!--GALLERY STARTS HERE -->

  <section class='gallery'>
 
<footer class="shym-contact">
      		 <!--======= GET IN TOUCH PART =========-->
		
            <div class="col-md-6 col-sm-6"> <i class="ion-flag"></i>
              <h4><center>SIGN IN</h4></center>
              <div id="contact_form">
                <form id="form2" name="form2" class="contact-form " action="si.php" accept-charset="utf-8" method="post" >
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label><span>Name</span>
                          <input name="name1" type="text"  placeholder="Name"/>
                        </label>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>
                          <input name="email" type="email" placeholder="Email"/>
                        </label>
                      </div>
                    </div>
                    <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label><span>Username</span>
                          <input name="username" type="text" placeholder="Username"/>
                        </label>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>
                          <input name="password" type="password" placeholder="Password"/>
                        </label>
 			<input name="submit" type="submit" value="SIGN IN" onClick="isValid();" />
        
                      </div>

		
                    </div>
                </form>
		            <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
		</div>
      </div>
    </div>

    
  </footer>
   
  
</section>
  
 

	
  
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script> 
	<script src="js/scrollReveal.js"></script>
	<script src="js/function.js"></script>
	
	


   	





</body>
<script>
<!--
 function isValid()
 {
 
 	//alert("hi");
	var name1;
	name1=document.form2.name1.value;
	var email1;
	email1=document.form2.email.value;
	var user;
	user=document.form2.username.value;
	var pass;
	pass=document.form2.password.value;
	if(user=="" && pass=="" && name1=="" && email1=="")
	{
		alert("Please enter username & Password & name & email");
		return false;
	}
	else if(user=="")
	{
		alert("please enter username");
		return false;
	}
	
	else if(pass=="")
	{
		alert("please enter password");
		return false;
	}
	else if(name1=="")
	{
		alert("please enter name");
		return false;
	}
	else if(email1=="")
	{
		alert("please enter email address");
		return false;
	}
	
	//check();
	return true;
}
  
 -->
</script>

</html>

	
