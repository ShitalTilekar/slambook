<?php
//session_start();
$servername = "Localhost";
$username1 = "root";
$password1 = "qwerty";
$dbname = "slambook";

//require_once("SQLSettings.php");
$name = $_POST["name1"];
$email= $_POST["email"];
$msg = $_POST["username"];
$pass = $_POST["password"];
$conn = new mysqli($servername, $username1, $password1, $dbname);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}



$sql = "INSERT INTO signin (name, email, username, password) VALUES ('$name', '$email', '$msg', '$pass')";
$conn->query($sql);

	
echo "hello";
header("location: login.php");
?>
