<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>
slambook created by shital tilekar...
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->

</head>

<body>
<!-- PRELOADER STARTS HERE -->
  <div class="shym-preloader"></div>
  <!-- /PRELOADER ENDS HERE-->
  
  
  
<!-- HEADER STARTS HERE --> 
 <header class="navbar navbar-inverse navbar-fixed-top heading" role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle togglebutton" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>


</button>


 <h3>My Slambook......</h3></a>

</div>

 <div class="collapse navbar-collapse menubar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" ><i class="fa fa-fw fa-home"></i>Home</a>
					<ul class="dropdown-menu">
					
					</ul>
                    <li><a href="index.php"></i>LogOut</a></li>
                   
                        
            </div>
			
</div>
</header><!---->

<!-- HEADER ENDS HERE -->

<!--GALLERY STARTS HERE -->

  <section class='gallery'>
 			
			<footer class="shym-contact">
      		 <!--======= GET IN TOUCH PART =========-->
		
            <div class="col-md-6 col-sm-6"> <i class="ion-flag"></i>
              <h4>FIll SLAMBOOK.........</h4>
              <div id="contact_form">
                <form id="form4" name="form4" action="sl.php" class="contact-form " accept-charset="utf-8" method="post" >
                  <div class="col-sm-8">
                        <label><span>First Name</span>
                          <input name="firstname" type="text" placeholder="First Name"/>
                        </label>
                     <label><span>Name</span>
                          <input name="lastname" type="text" placeholder="Last Name"/>
                        </label>
			<label><span>your college</span>
                          <input name="college" type="text" placeholder="Your College Name"/>
                        </label>
			<label><span>where we meet</span>
                          <input name="wherewemeet" type="text" placeholder="Where we meet"/>
                        </label>
			<label><span>Date of Birth</span>
                          <input name="birthdate" type="text" placeholder="Your Birthdate"/>
                        </label>
			<label><span>Hobbies</span>
                          <input name="hobbies" type="text" placeholder="Hobbies"/>
                        </label>
			<label><span>Address</span>
                          <input name="address" type="text" placeholder="Your Address"/>
                        </label>
			<label><span>Color</span>
                          <input name="color" type="text" placeholder="Which color you like most"/>
                        </label>
			
			<label><span>Crush name</span>
                          <input name="crush" type="text" placeholder="your crush name"/>
                        </label>
			<label><span>favorite person</span>
                          <input name="person" type="text" placeholder="your Favourite Person Ever...."/>
                        </label>
			<label><span>subject</span>
                          <input name="subject" type="text" placeholder="your favourite subject"/>
                        </label>
			<label><span>Sugeestion</span>
                          <input name="suggestion" type="text" placeholder="Any Suggestion For me"/>
                        </label>
			<input name="submit" type="submit" value="SUBMIT" onClick="isValid();" />
			 </div>

			
                    </div>
			
                </form>
				     
       <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
		</div>
      </div>
    </div>

    
  </footer>
   
</section>
  
 

	
  
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script> 
	<script src="js/scrollReveal.js"></script>
	<script src="js/function.js"></script>
	
	


   	





</body>
<script>
<!--
 function isValid()
 {
 
 	//alert("hi");
	var fname;
	fname=document.form4.firstname.value;
	var lname;
	lname=document.form4.lastname.value;
	var clg;
	clg=document.form4.college.value;
	var meet;
	meet=document.form4.wherewemeet.value;

	var dob ;
	dob=document.form4.birthdate.value;
	var hobi;
	hobi=document.form4.hobbies.value;
	var addr;
	addr=document.form4.address.value;
	var col;
	col=document.form4.color.value;

	var crushn;
	crushn=document.form4.crush.value;
	var per;
	per=document.form4.person.value;
	var sub;
	sub=document.form4.subject.value;
	var suggest;
	suggest=document.form4.suggestion.value;
	if(fname=="" && lname=="" && clg=="" && meet=="" && dob=="" && hobi=="" && addr=="" && col=="" && crushn=="" && per=="" && sub=="" && suggest=="")
	{
		alert("Please enter details");
		return false;
	}
	else if(fname=="")
	{
		alert("please enter your first name");
		return false;
	}
	
	else if(lname=="")
	{
		alert("please enter your lastname ");
		return false;
	}
	else if(clg=="")
	{
		alert("please enter your college name");
		return false;
	}
	else if(meet=="")
	{
		alert("please state that where we meet?");
		return false;
	}
	else if(dob=="")
	{
		alert("please enter your birthdate");
		return false;
	}
	else if(hobi=="")
	{
		alert("please state your hobbies");
		return false;
	}
	else if(addr=="")
	{
		alert("please state your address?");
		return false;
	}
	else if(col=="")
	{
		alert("please state your favourite color");
		return false;
	}
	else if(crushn=="")
	{
		alert("please enter your crush name");
		return false;
	}
	else if(per=="")
	{
		alert("please state your favourite person");
		return false;
	}
	else if(sub=="")
	{
		alert("please enter your favourite subject");
		return false;
	}
	else if(suggest=="")
	{
		alert("please give me some suggestion");
		return false;
	}
	
	//check();
	return true;
}
  
 -->
</script>
</html>

<?php
include_once('connection.php');

session_start();

$cn=new connection;
		$conn=$cn->getConnection();


 
	if($_GET['action']=='insert')
	{
	   if($_POST['username'])
	 {
		$sql=mysqli_query($conn,"select count(*) as total from slambook WHERE username='".$_POST['username']."' ");
			
		$result=mysqli_fetch_row($sql);
		$json=array('IsEmail'	=>	$result);
		
		$i=0;
					
		
	}
	if($json['IsEmail'][0]>0)
	{
	  header("Location:note1.php");
		
	}
	
	else
	{	
		
   $result="insert into slambook(firstname,lastname,college,wherewemeet,birthdate,hobbies,address,color,crush,person,subject,suggestion)values('$_POST[firstname]','$_POST[lastename]','$_POST[college]','$_POST[wherewemeet]','$_POST[birthdate]','$_POST[hobbies]','$_POST[address]','$_POST[color]','$_POST[crush]','$_POST[person]','$_POST[subject]','$_POST[suggestion]')";
	}
   if(!mysqli_query($conn,$result))
   {
     
	 die('Error: ' . mysqli_error($conn));
   
   }
   else
   {
	   
     header("Location:note.php?");
   }

   
	}
	
	?>
	
	
	





