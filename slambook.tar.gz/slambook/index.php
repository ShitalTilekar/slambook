<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>
slambook created by shital tilekar...
</title>
<meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css">
<link href="font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
 <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
 <![endif]-->

</head>

<body>
<!-- PRELOADER STARTS HERE -->
  <div class="shym-preloader"></div>
  <!-- /PRELOADER ENDS HERE-->
  
  
  
<!-- HEADER STARTS HERE --> 
 <header class="navbar navbar-inverse navbar-fixed-top heading" role="banner">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle togglebutton" data-toggle="collapse" data-target=".navbar-collapse">
<span class="sr-only">Toggle</span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>


</button>


 <h3>My Slambook...</h3></a>

</div>

 <div class="collapse navbar-collapse menubar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" ><i class="fa fa-fw fa-home"></i>Home</a>
					<ul class="dropdown-menu">
					
					</ul>
                    <li><a href="signup.php"></i>SIGN IN</a></li>
                    <li><a href="login.php"></i>LOGIN...</a></li>
                 
                        
            </div>
			
</div>
</header><!---->

<!-- HEADER ENDS HERE -->

<!--GALLERY STARTS HERE -->

  <section class='gallery'>
  
  
   <div class="home-caption">
                <div class="home-title">A Platform to ..........</div>
                <div class="home-title">Say Everything is...</div>
                <div class="home-title">Slambook.....</a>
            </div>
  
  
</section>
  
  <!-- /GALLERY ENDS HERE -->
  <!-- OPTION STARTS HERE-->
  <section class='shym-option'>
  <div class='container'>
  <div class="row">
        
        
        
        
      </div>
      <!-- /COLUMNS -->
    </div>
  </section>
    <!-- /OPTION ENDS HERE -->
	
<!--APPLICATION ENDS HERE -->
<section class='shym-application'>
<div class='container'>

<div class='row'>
<div class='col-xs-12 shym-application-data'>
<h2 class='shym-text-uppercase'>To fill Slambook, SIGN IN and then Log IN...</a></h2>
</div>
</div>




</div>

</section>
	
<!--/APPLICATION ENDS HERE-->	
	
<!--FEATURE STARTS HERE-->

<!--/FEATURE ENDS HERE -->

<!--SHYM-USER STARTS HERE -->
	
<section class='shym-user'>
<div class='container'>
<div class='shym-user-title' >
        <h3 class='shym-text-center shym-text-uppercase'>Best Pictures</h3>
        <hr>
        <p class='shym-text-center'>Friends are like computer,I "Enter" in your Life,"Save" you in my heart, "Format" ure problems "Shift" you to apportunities & never delete you from my memory...</p>
      </div>
      
      <!--======= SLIDER PART =========-->
      <div id="owl-team"> 
        
        <!--======= SLIDER PART =========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/coep.jpg" alt="" >
            <div class="over">
			<i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
                <p>#coepins#Masti#Fun#Jokes#BFF</p>
              </div>
            </div>
          </div>
          <div class="info">
            <h4>Bestieee</h4>
            
            <hr>
            
              
          </div>
        </div>
        
        <!--======= SLIDER PART =========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/grp.jpg" alt="" >
            <div class="over">
			<i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
              
                <p>our TM group.....we always do fun, masti and all...</p>
              </div>
            </div>
          </div>
          <div class="info">
           <h4>Friends Forever</h4>
            
            <hr>
           
          </div>
        </div>
        
        <!--======= SLIDER PART =========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/birthday.jpg" alt="" >
            <div class="over">
              <i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
                <p>we always be friends forever....enjoy a lot guys with you.</p>
              </div>
            </div>
          </div>
          <div class="info">
            <h4>Dosti</h4>
           
            <hr>
           
          </div>
        </div>
        
        <!--======= SLIDER PART=========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/shirya.jpg" alt="" >
            <div class="over">
              <i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
                <p>Thank you for being such a nice friends ... i will always remembered you.</p>
              </div>
            </div>
          </div>
          <div class="info">
            <h4>Friends</h4>
           
            <hr>
            
          </div>
        </div>
		
		
        
        <!--======= SLIDER PART =========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/rahu.jpg" alt="" >
            <div class="over">
              <i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
                <p>I always miss my schools days and all of you also...</p>
              </div>
            </div>
          </div>
          <div class="info">
            <h4>Friendship</h4>
            
            <hr>
            
          </div>
        </div>
		
		<!--======= SLIDER PART =========-->
        <div class="team">
          <div class="img"> <img class="img-responsive" src="img/gpp.jpg" alt="" >
            <div class="over">
<i class="fa fa-eye"></i>
              <div class="des"> <a href="#"></a>
                <p>Miss you guyz.. we had a great fun together..thanks for being my friends....</p>
              </div>
            </div>
          </div>
          <div class="info">
            <h4>Best Friends</h4>
           
            <hr>
            
          </div>
        </div>
		
		
		
		
		
		
		
		
      </div>
</div>
</section>
	<!--/SHYM -USER ENDS HERE -->
<!--PICTURE INFORMATION STARTS HERE-->
<section class='picture-information'>
<div class='container'>
<div class='row'>
<div class='col-md-12 shym-text-center'>
<h3 class='shym-text-uppercase'>where we meet......</h3> 
</div>


<div class='gap'>

</div>
<div class='col-md-12 col-sm-12 col-xs-12'>
<div class='col-sm-3 '>
<div class='picture-info' data-scroll-reveal="wait 0.25s, then enter right and move 40px over 1s">
<img src='img/p.jpg'/>
<p>Primary School, Rahu</p>
<div class="shym-overlay">
                            <div class="shym-picture-detail-inner">
                                <h3><a href="#">childhood..</a> </h3>
                                <p> primary School..</p>
                               
                            </div> 
                        </div>
						</div>
</div>
<div class='col-sm-3 '>
<div class='picture-info' data-scroll-reveal="wait 0.25s, then enter left and move 40px over 1s">
<img src='img/kvmrs.jpg'/>
<p>Kailas Vidya Mandir, Rahu</p>
<div class="shym-overlay">
                            <div class="shym-picture-detail-inner">
                                <h3><a href="#">School</a> </h3>
                                <p>Secondary School</p>
                                
                            </div> 
                        </div>
						</div>
</div>
<div class='col-sm-3'>
<div class='picture-info' data-scroll-reveal="wait 0.25s, then enter bottom and move 40px over 1s">
<img src='img/gppc.jpg'/>
<p>Government Polytechnic ,Pune</p>
<div class="shym-overlay">
                            <div class="shym-picture-detail-inner">
                                <h3><a href="#">College</a> </h3>
                                <p>Diploma College</p>
                                
                            </div> 
                        </div>
						</div>
</div>
<div class='col-sm-3'>
<div class='picture-info' data-scroll-reveal="wait 0.25s, then enter top and move 40px over 1s">
<img src='img/coepc.jpg'/>
<p>College Of Engineering Pune.</p>
<div class="shym-overlay">
                            <div class="shym-picture-detail-inner">
                                <h3><a href="#">College</a> </h3>
                                <p>B.Tech College</p>
                                
                            </div> 
							</div>
</div>
</div>

</div>

</div>
</div>

</section>
<!--/PICTURE INFORMATION ENDS HERE -->



<!--SHYM CONTACT START HERE -->
<footer class="shym-contact">
    
      <div class="container"> 
        
        <!--======= TITTLE PART =========-->
        <div class="tittle">
          <h3 class='shym-text-center'>Feedback</h3>
          <hr>
          <p class='shym-text-center'>Thank you For visiting My Site...If you want Give me feedback.</p>
        </div>
        
        <!--======= SOCIAL ICONS PART =========-->
        <div class="social_icons">
          <ul>
            
            
          </ul>
        </div>
        
        
               
            <!--======= GET IN TOUCH PART =========-->
		
            <div class="col-md-6 col-sm-6"> <i class="ion-flag"></i>
              <h4><center>GET IN TOUCH</h4></center>
              <div id="contact_form">
                <form id="form1" name="form1" action="feed.php" class="contact-form " accept-charset="utf-8" method="post" >
                  <div class="row">
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label><span>Name</span>
                          <input name="name1" type="text" placeholder="Name"/>
                        </label>
                      </div>
                    </div>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>
                          <input name="email" type="email" placeholder="Email"/>
                        </label>
                      </div>
                    </div>
                    <div class="col-md-12">
                      <label> <span>Message</span>
                        <textarea name="message1" placeholder="Your Message"></textarea>
                      </label>
                      <input name="submit" type="submit" value="SUBMIT YOUR FEEDBACK" onClick="isValid();" />
                    </div>
                  </div>
                </form>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
		</div>
      </div>
    </div>

    
  </footer>

	
  
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script type="text/javascript" src="js/owl.carousel.min.js"></script> 
	<script src="js/scrollReveal.js"></script>
	<script src="js/function.js"></script>
	
	
   	





</body>
<script>
<!--
 function isValid()
 {
 
 
	var user;
	user=document.form1.name1.value;
	var pass;
	pass=document.form1.email.value;
	var msg;
	msg=document.form1.message1.value;
	if(user=="" && pass=="" && msg=="")
	{
		alert("Please enter username & Password & message");
		return false;
	}
	else if(user=="")
	{
		alert("please enter name");
		return false;
	}
	
	else if(pass=="")
	{
		alert("please enter email");
		return false;
	}
	else if(msg=="")
	{
		alert("please enter message");
		return false;
	}
	
	//check();
	return true;
}
  
 -->
</script>
</html>


