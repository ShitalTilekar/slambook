<?php
//session_start();
$servername = "Localhost";
$username = "root";
$password = "qwerty";
$dbname = "slambook";

//require_once("SQLSettings.php");
$fname = $_POST["firstname"];
$lname= $_POST["lastname"];
$clg = $_POST["college"];
$meet = $_POST["wherewemeet"];
$dob = $_POST["birthdate"];
$hb = $_POST["hobbies"];
$addr = $_POST["address"];
$color = $_POST["color"];
$crushn = $_POST["crush"];
$per = $_POST["person"];
$sub = $_POST["subject"];
$sug = $_POST["suggestion"];
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}



$sql = "INSERT INTO slambook (firstname, lastname, college, wherewemeet, birthdate, hobbies, address, color, crush, person, subject, suggestion) VALUES ('$fname', '$lname', '$clg' , '$meet', '$dob', '$hb', '$addr', '$color', '$crushn', '$per', '$sub', '$sug')";
$conn->query($sql);

	
echo "Thank you...!!!!";
header("location: index1.php");
?>
