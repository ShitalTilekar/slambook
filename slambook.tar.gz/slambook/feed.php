<?php
//session_start();
$servername = "Localhost";
$username = "root";
$password = "qwerty";
$dbname = "slambook";

//require_once("SQLSettings.php");
$name = $_POST["name1"];
$email= $_POST["email"];
$msg = $_POST["message1"];

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
}



$sql = "INSERT INTO feedback (name, email, msg) VALUES ('$name', '$email', '$msg')";
$conn->query($sql);

	
echo "hello";
header("location: index.php");
?>
